import pytest
import test_v05_authority as authority_tests
import test_v05_authority_providers as provider_tests
from test_v05_lifecycle import manager_for
from accretion.robotics.runtime_store import RuntimeBinding

lab = authority_tests.lab
inventory = provider_tests.inventory

async def test_polluter_then_unfiltered_reconcile(inventory, tmp_path, monkeypatch):
    i = inventory
    bind = i.lab.bind
    original = None
    async def capture_original():
        nonlocal original
        ep = await bind()
        async with i.lab.authority.store.transaction(i.lab.project) as tx:
            original = await tx.get(RuntimeBinding, ep.binding_id)
        return ep
    monkeypatch.setattr(i.lab, 'bind', capture_original)
    try:
        await provider_tests.test_policy_refusals_leave_state_unchanged(i, 'wrong_orchestrator')
        await manager_for(i.lab, tmp_path).reconcile()
    finally:
        # Restore only this deliberate before-repair reproduction's exact row.
        if original is not None:
            async with i.lab.authority.store.transaction(i.lab.project) as tx:
                await tx.put(original)
